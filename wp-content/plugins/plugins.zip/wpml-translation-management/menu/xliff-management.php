
<script type="text/javascript">
var wpml_xliff_ajxloaderimg_src = '<?php echo WPML_XLIFF_TM_URL ?>/res/img/ajax-loader.gif';
var wpml_xliff_ajxloaderimg = '<img src="'+wpml_xliff_ajxloaderimg_src+'" alt="loading" width="16" height="16" />';
</script>

<div class="wrap">
    <h2><?php echo __('XLIFF translation', 'wpml-xliff') ?></h2>    

</div>
